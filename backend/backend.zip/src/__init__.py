"""Application configuration package."""
