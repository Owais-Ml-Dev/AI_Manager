class AssistantMessage {
  final String text;
  final bool fromUser;
  final String? provider;
  final String? model;
  final bool fallbackUsed;

  const AssistantMessage({
    required this.text,
    required this.fromUser,
    this.provider,
    this.model,
    this.fallbackUsed = false,
  });
}
