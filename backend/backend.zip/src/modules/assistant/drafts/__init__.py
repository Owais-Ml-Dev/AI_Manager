"""Server-side assistant drafts."""
